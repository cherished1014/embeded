/* libra.h */

#include<stdio.h>

void constellation(void);
void sign(void);
