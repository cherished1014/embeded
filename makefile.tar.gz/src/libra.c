#include "libra.h"

void constellation(void)
{
	printf("libra duration:09.23~10.22\n");

}
