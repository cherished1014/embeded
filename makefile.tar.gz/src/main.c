#include "libra.h"

int main(void)
{
		constellation();
		sign();
		return 0;
}
