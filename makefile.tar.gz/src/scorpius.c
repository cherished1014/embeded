#include "libra.h"

void  sign(void)
{
	
	printf("Scolpius duration : 10.23~11.22\n");

}
